(function() {
    // (1) CDP EVENT OBSERVER: load JavaScript code

    if (typeof dcdpProfileInfo !== 'undefined') {
        // Observer ID
        window.leoObserverId = dcdpProfileInfo.observer_id || '';
        
        // CDN of JS
        window.leoObserverLogDomain = dcdpProfileInfo.observer_log_domain || '';

        if(window.leoObserverId.length === 0 || window.leoObserverLogDomain.length === 0) {
            return;
        }

        window.leoObserverCdnDomain = "cdn.jsdelivr.net/gh/USPA-Technology/leo-cdp-static-files@v0.8.9.27";
        
        // Data Touchpoint Metadata 
        window.srcTouchpointName = encodeURIComponent(document.title);
        window.srcTouchpointUrl = encodeURIComponent(location.href);

        // the main proxy CDP JS
        var leoproxyJsPath = '/js/leo-observer/leo.proxy.min.js';
        var src = location.protocol + '//' + window.leoObserverCdnDomain + leoproxyJsPath;
        var jsNode = document.createElement('script');
        jsNode.async=true; jsNode.defer=true; jsNode.src = src;
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(jsNode, s);
    }
})();


var parseDataUTM = window.parseDataUTM || function () {
    if (location.search.indexOf('utm_') > 0) {
        var search = location.search.substring(1);
        var json = decodeURI(search).replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g, '":"');
        return JSON.parse('{"' + json + '"}');
    }
}
	
// (2) CDP EVENT OBSERVER: set-up all event tracking functions
var LeoObserver = {};

// (2.1) function to track View Event "AdImpression"
LeoObserver.recordEventAdImpression = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordViewEvent("ad-impression",eventData);
}

// (2.2) function to track View Event "PageView"
LeoObserver.recordEventPageView = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordViewEvent("page-view",eventData);
}

// (2.3) function to track View Event "AcceptTracking"
LeoObserver.recordEventAcceptTracking = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordViewEvent("accept-tracking",eventData);
}

// (2.4) function to track View Event "EngagedSession"
LeoObserver.recordEventEngagedSession = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordViewEvent("engaged-session",eventData);
}

// (2.5) function to track Action Event "Like"
LeoObserver.recordEventLike = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordActionEvent("like",eventData);
}

// (2.6) function to track View Event "ContentView"
LeoObserver.recordEventContentView = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordViewEvent("content-view",eventData);
}

// (2.7) function to track Action Event "Search"
LeoObserver.recordEventSearch = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordActionEvent("search",eventData);
}

// (2.8) function to track View Event "ItemView"
LeoObserver.recordEventItemView = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordViewEvent("item-view",eventData);
}

// (2.9) function to track Action Event "ClickDetails"
LeoObserver.recordEventClickDetails = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordActionEvent("click-details",eventData);
}

// (2.10) function to track Action Event "PlayVideo"
LeoObserver.recordEventPlayVideo = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordActionEvent("play-video",eventData);
}

// (2.11) function to track Action Event "SubmitContact"
LeoObserver.recordEventSubmitContact = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordActionEvent("submit-contact",eventData);
}

// (2.12) function to track Action Event "AdminView"
LeoObserver.recordEventAdminView = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordActionEvent("admin-view",eventData);
}

// (2.13) function to track Action Event "FileDownload"
LeoObserver.recordEventFileDownload = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordActionEvent("file-download",eventData);
}

// (2.14) function to track Action Event "RegisterAccount"
LeoObserver.recordEventRegisterAccount = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordActionEvent("register-account",eventData);
}

// (2.15) function to track Action Event "UserLogin"
LeoObserver.recordEventUserLogin = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordActionEvent("user-login",eventData);
}

// (2.16) function to track Action Event "ShortLinkClick"
LeoObserver.recordEventShortLinkClick = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordActionEvent("short-link-click",eventData);
}

// (2.17) function to track Action Event "AskQuestion"
LeoObserver.recordEventAskQuestion = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordActionEvent("ask-question",eventData);
}

// (2.18) function to track Action Event "ProductTrial"
LeoObserver.recordEventProductTrial = function(eventData) {
	eventData = eventData ? eventData : {};
	LeoObserverProxy.recordActionEvent("product-trial",eventData);
}

// (2.19) function to track Conversion Event "Purchase"
LeoObserver.recordEventPurchase = function(eventData, shoppingCartItems, transactionId, transactionValue, currencyCode) {
	// need 5 params
	eventData = typeof eventData === "object" ? eventData : {};
	shoppingCartItems = typeof shoppingCartItems === "object" ? shoppingCartItems : [];
	transactionId = typeof transactionId === "string" ? transactionId : "";
	transactionValue = typeof transactionValue === "number" ? transactionValue : 0;
	currencyCode = typeof currencyCode === "string" ? currencyCode : "USD";
	LeoObserverProxy.recordConversionEvent("purchase", eventData , transactionId, shoppingCartItems, transactionValue, currencyCode);
}

// (2.20) function to track Action Event "ProductTrial"
LeoObserver.recordEventAddToCart = function(eventData) {
    eventData = eventData ? eventData : {};
    LeoObserverProxy.recordActionEvent("add-to-cart",eventData);
}

// (2.21) function to track Action Event "Dislike"
LeoObserver.recordEventDislike = function(eventData) {
    eventData = eventData ? eventData : {};
    LeoObserverProxy.recordActionEvent("dislike",eventData);
}


// (3) CDP EVENT OBSERVER is ready
function leoObserverProxyReady(session) {
   	// auto tracking when CDP JS is ready
   	LeoObserver.recordEventPageView(parseDataUTM()) ;
    
    // woocommerce tracking
    setUpWooCommerceTrackingEvents();
   	
   	// set tracking CDP web visitor ID into all a[href] nodes
	LeoObserverProxy.synchLeoVisitorId(function(vid){
		var aNodes = document.querySelectorAll('a');
		[].forEach.call(aNodes, function(aNode) {
			var hrefUrl = aNode.href || "";
            var check = hrefUrl.indexOf('http') >= 0 && hrefUrl.indexOf(location.host) < 0 ;
			if(check) {
				if(hrefUrl.indexOf('?') > 0) hrefUrl += ("&leosyn=" + vid);
				else hrefUrl += ("?leosyn=" + vid);
				aNode.href = hrefUrl;
			}
		});
		if(typeof window.synchLeoCdpToGA4 === "function") {
			window.synchLeoCdpToGA4(vid)
		}
	});

    // update user profile to CDP
    LeoObserver.updateProfile(dcdpProfileInfo.first_name, dcdpProfileInfo.last_name, dcdpProfileInfo.email, dcdpProfileInfo.phone);
}

// track users when they click any link in the web-page
LeoObserver.addTrackingAllLinks = function(){
    setTimeout(function(){
        document.querySelectorAll('a').forEach(function (e) {
            e.addEventListener('click',function(){
                var url = e.getAttribute('href') || "";
                var data = {'url': url, 'link-text' : e.innerText };
                LeoObserver.recordEventClickDetails(data)
            })
        })
    },1500);
}

// track users when they click any button in the web-page
LeoObserver.addTrackingAllButtons = function(){
    setTimeout(function(){
        document.querySelectorAll('button').forEach(function (e) {
            e.addEventListener('click',function(){
                var data = {'button-text' : e.innerText };
                LeoObserver.recordEventClickDetails(data)
            })
        })
    },1600);
}

LeoObserver.updateProfile = function(firstName, lastName, email, phone) {
    var isValid = (typeof email === 'string' && email.length > 0) || (typeof phone === 'string' && phone.length > 0);
    if(typeof window.LeoObserverProxy ==='object' &&  isValid) {
        var userData = {'firstName': firstName, 'lastName': lastName, 'email':email, 'phone': phone, loginId : "" ,loginProvider: location.host};
        setTimeout(function(){
            LeoObserverProxy.updateProfileBySession(userData);
        },2000)
    } else {
        console.log("LeoObserverProxy is not defined");
    }
}

// tracking 
// EXECUTE TRACKING EVENTS  
function setUpWooCommerceTrackingEvents() {
    // Add product to cart from a list
    var list_view_added_to_cart_event = function(event) {
        console.log(event);

        var product_id = event.target.dataset.product_id;
        var product_name = event.target.closest('.product').querySelector('.woocommerce-loop-product__title').textContent.trim();

        var data = {
            'Product ID': product_id,
            'Product Name': product_name,
            'Quantity': '1',
        };

        LeoObserver.recordEventAddToCart(data);
    };

    // Add product to cart from product's details screen
    var single_view_added_to_cart_event = function(event) {
        console.log(event);

        const table = document.querySelector('.variations');
        const radios = table.querySelectorAll('input[type="radio"]');
        const select = table.querySelector('select');

        let selectedRadioValue;
        radios.forEach(function(radio) {
            if (radio.checked) {
                selectedRadioValue = radio.value;
            }
        });

        let selectedSelectValue = select ? select.value : null;

        var product_id = event.target.value || document.querySelector('input[name="add-to-cart"]').value || document.querySelector('.variations_form').dataset.product_id;
        var product_name = document.querySelector('.product_title').textContent.trim();
        var quantity = document.querySelector('.quantity input[name="quantity"]').value;
        var variation = selectedRadioValue || selectedSelectValue || null

        var data = {
            'Product ID': product_id,
            'Product Name': product_name,
            'Variation': variation,
            'Quantity': quantity
        };

        LeoObserver.recordEventAddToCart(data);
    };

    // Remove a product from cart screen
    var remove_from_cart_event = function(event) {
        console.log(event);

        var product_id = this.getAttribute('data-product_id');
        var action_name = this.getAttribute('aria-label');

        LeoObserver.recordEventRemoveFromCart({
            'Product ID': product_id,
            'Action Name': action_name,
        });
    };

    // Add product to wishlist from a list
    var list_view_added_to_wishlist_event = function(event) {
        event.preventDefault();

        var productId = event.target.dataset.originalProductId;
        var productItem = document.querySelector('.products .post-' + productId);
        var productName = productItem.querySelector('.product-title, .woocommerce-loop-product__title').textContent.trim();
        var originalPrice = productItem.querySelector('.price del .woocommerce-Price-amount') ? productItem.querySelector('.price del .woocommerce-Price-amount').textContent.trim() : null;
        var salePrice = productItem.querySelector('.price ins .woocommerce-Price-amount') ? productItem.querySelector('.price ins .woocommerce-Price-amount').textContent.trim() : null;

        if (!salePrice) {
            salePrice = productItem.querySelector('.price .woocommerce-Price-amount').textContent.trim();
            originalPrice = null;
        }

        var data = {
            'First Name': dcdpProfileInfo.first_name,
            'Last Name': dcdpProfileInfo.last_name,
            'Email': dcdpProfileInfo.email,
            'Phone': dcdpProfileInfo.phone,
            'Login ID': '',
            'Login Provider': location.host,
            'Product Name': productName,
            'Sale Price': salePrice,
            'Original Price': originalPrice,
        };

        LeoObserver.recordEventLike(data);
    };

    // Remove a product from wishlist on wishlist screen
    var remove_from_wishlist_event = function(event) {
        event.preventDefault();
        console.log(event);

        var removed_item = event.target.closest('tr');
        var product_name = removed_item.querySelector('.product-name').textContent.trim();

        var data = {
            'First Name': dcdpProfileInfo.first_name,
            'Last Name': dcdpProfileInfo.last_name,
            'Email': dcdpProfileInfo.email,
            'Phone': dcdpProfileInfo.phone,
            'Login ID': '',
            'Login Provider': location.host,
            'Product Name': product_name,
        };

        LeoObserver.recordEventDislike(data);
    };

    
    // Catch events from components
    document.querySelectorAll('.wishlist_table .remove_from_wishlist').forEach(function(button) {
        button.addEventListener('click', remove_from_wishlist_event);
    });

    document.querySelectorAll('.products .add_to_wishlist').forEach(function(button) {
        button.addEventListener('click', list_view_added_to_wishlist_event);
    });

    document.querySelectorAll('.product .single_add_to_cart_button').forEach(function(button) {
        button.addEventListener('click', single_view_added_to_cart_event);
    });

    document.querySelectorAll('.product button[name*="buy-now"]').forEach(function(button) {
        button.addEventListener('click', single_view_added_to_cart_event);
    });

    document.querySelectorAll('.cart a[href*="remove_item"]').forEach(function(button) {
        button.addEventListener('click', remove_from_cart_event);
    });

    document.body.addEventListener('added_to_cart', list_view_added_to_cart_event);
    // document.body.addEventListener('added_to_wishlist', list_view_added_to_wishlist_event);
};